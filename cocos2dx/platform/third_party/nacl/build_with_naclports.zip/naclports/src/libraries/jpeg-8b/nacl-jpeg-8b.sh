#!/bin/bash

readonly URL=http://www.imagemagick.org/download/delegates/jpegsrc.v8b.tar.gz
readonly PATCH_FILE=nacl-jpeg-8b.patch
readonly PACKAGE_NAME=jpeg-8b

source ../../build_tools/common.sh

DefaultPackageInstall
exit 0
