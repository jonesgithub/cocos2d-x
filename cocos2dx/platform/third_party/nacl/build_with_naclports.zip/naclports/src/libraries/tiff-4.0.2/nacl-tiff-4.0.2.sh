#!/bin/bash

readonly URL=http://www.imagemagick.org/download/delegates/tiff-4.0.2.tar.gz
readonly PATCH_FILE=nacl-tiff-4.0.2.patch
readonly PACKAGE_NAME=tiff-4.0.2

source ../../build_tools/common.sh

export LIBS="-lnosys -lm"

DefaultPackageInstall
exit 0

